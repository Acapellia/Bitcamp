//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Tetris3.rc
//
#define IDR_MENU1                       101
#define IDR_ACCELERATOR1                102
#define IDB_BITMAP1                     103
#define IDB_BITMAP2                     104
#define IDB_BITMAP3                     105
#define IDB_BITMAP4                     106
#define IDB_BITMAP5                     107
#define IDB_BITMAP6                     108
#define IDB_BITMAP7                     109
#define IDB_BITMAP8                     110
#define IDB_BITMAP9                     111
#define IDB_BITMAP10                    112
#define IDB_BITMAP11                    113
#define IDI_ICON1                       114
#define IDR_WAVE2                       116
#define IDR_WAVE3                       117
#define IDR_WAVE4                       119
#define IDR_WAVE1                       120
#define IDM_GAME_START                  40001
#define IDM_GAME_PAUSE                  40002
#define IDM_GAME_EXIT                   40003
#define IDM_GAME_VIEWSPACE              40004
#define IDM_GAME_QUIET                  40005
#define IDM_GAME_SIZE1                  40006
#define IDM_GAME_SIZE2                  40007
#define IDM_GAME_SIZE3                  40008
#define IDM_GAME_SIZE4                  40009
#define IDM_GAME_SIZE5                  40010

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        121
#define _APS_NEXT_COMMAND_VALUE         40011
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
