#pragma once
#define NAME_LEN		20
#define TEL_LEN			20
#define MAX_PERSON_NUM	100